/* ============================================
   GUILHERME MORELI - PORTFOLIO SCRIPTS
   ============================================ */

document.addEventListener('DOMContentLoaded', () => {
  // --- Cursor Glow Effect (desktop only) ---
  initCursorGlow();

  // --- Mobile Menu ---
  initMobileMenu();

  // --- Navbar Scroll Effect ---
  initNavbarScroll();

  // --- Smooth Scroll for Anchor Links ---
  initSmoothScroll();

  // --- Scroll Reveal Animations ---
  initScrollReveal();

  // --- Black Hole Particles ---
  initBlackHoleParticles();

  // --- Active Nav Link Highlight ---
  initActiveNavHighlight();

  // --- Typed Effect for Hero Role ---
  initTypedEffect();
});

/* ----------------------------------------
   CURSOR GLOW - Subtle purple light follows cursor
   ---------------------------------------- */
function initCursorGlow() {
  const glow = document.querySelector('.cursor-glow');
  if (!glow || window.innerWidth < 768) return;

  let mouseX = 0, mouseY = 0;
  let glowX = 0, glowY = 0;

  document.addEventListener('mousemove', (e) => {
    mouseX = e.clientX;
    mouseY = e.clientY;
  });

  function animate() {
    // Smooth follow with easing
    glowX += (mouseX - glowX) * 0.08;
    glowY += (mouseY - glowY) * 0.08;
    glow.style.left = glowX + 'px';
    glow.style.top = glowY + 'px';
    requestAnimationFrame(animate);
  }
  animate();
}

/* ----------------------------------------
   MOBILE MENU - Hamburger toggle
   ---------------------------------------- */
function initMobileMenu() {
  const toggle = document.querySelector('.menu-toggle');
  const navLinks = document.querySelector('.nav-links');
  if (!toggle || !navLinks) return;

  toggle.addEventListener('click', () => {
    toggle.classList.toggle('active');
    navLinks.classList.toggle('open');
    document.body.style.overflow = navLinks.classList.contains('open') ? 'hidden' : '';
  });

  // Close menu when a link is clicked
  navLinks.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
      toggle.classList.remove('active');
      navLinks.classList.remove('open');
      document.body.style.overflow = '';
    });
  });
}

/* ----------------------------------------
   NAVBAR SCROLL - Background change on scroll
   ---------------------------------------- */
function initNavbarScroll() {
  const nav = document.querySelector('.nav-container');
  if (!nav) return;

  window.addEventListener('scroll', () => {
    if (window.scrollY > 50) {
      nav.classList.add('scrolled');
    } else {
      nav.classList.remove('scrolled');
    }
  });
}

/* ----------------------------------------
   SMOOTH SCROLL - Anchor links scroll smoothly
   ---------------------------------------- */
function initSmoothScroll() {
  document.querySelectorAll('a[href^="#"]').forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const targetId = link.getAttribute('href');
      const target = document.querySelector(targetId);
      if (target) {
        const navHeight = document.querySelector('.nav-container')?.offsetHeight || 64;
        const targetPos = target.getBoundingClientRect().top + window.scrollY - navHeight;
        window.scrollTo({
          top: targetPos,
          behavior: 'smooth'
        });
      }
    });
  });
}

/* ----------------------------------------
   SCROLL REVEAL - Fade in elements on scroll
   ---------------------------------------- */
function initScrollReveal() {
  const reveals = document.querySelectorAll('.reveal, .reveal-children');
  if (!reveals.length) return;

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
      }
    });
  }, {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
  });

  reveals.forEach(el => observer.observe(el));
}

/* ----------------------------------------
   BLACK HOLE PARTICLES - Ambient floating particles
   ---------------------------------------- */
function initBlackHoleParticles() {
  const container = document.querySelector('.particles-container');
  if (!container) return;

  // Create particles that spiral toward center
  for (let i = 0; i < 30; i++) {
    const particle = document.createElement('div');
    particle.classList.add('particle');

    // Random starting positions around the black hole
    const angle = Math.random() * Math.PI * 2;
    const radius = 150 + Math.random() * 100;
    const startX = Math.cos(angle) * radius + 210;
    const startY = Math.sin(angle) * radius + 210;

    particle.style.left = startX + 'px';
    particle.style.top = startY + 'px';

    // Move toward center
    const tx = (210 - startX) * 0.7 + 'px';
    const ty = (210 - startY) * 0.7 + 'px';

    particle.style.setProperty('--tx', tx);
    particle.style.setProperty('--ty', ty);
    particle.style.setProperty('--duration', (3 + Math.random() * 4) + 's');
    particle.style.animationDelay = Math.random() * 5 + 's';
    particle.style.width = (1 + Math.random() * 2) + 'px';
    particle.style.height = particle.style.width;

    // Random color variation
    const colors = ['#8b5cf6', '#a78bfa', '#c4b5fd', '#7c3aed', '#6d28d9'];
    particle.style.background = colors[Math.floor(Math.random() * colors.length)];
    particle.style.boxShadow = `0 0 4px ${particle.style.background}`;

    container.appendChild(particle);
  }
}

/* ----------------------------------------
   ACTIVE NAV HIGHLIGHT - Highlight current section
   ---------------------------------------- */
function initActiveNavHighlight() {
  const sections = document.querySelectorAll('section[id]');
  const navItems = document.querySelectorAll('.nav-links a');
  if (!sections.length || !navItems.length) return;

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const id = entry.target.getAttribute('id');
        navItems.forEach(item => {
          item.style.color = '';
          if (item.getAttribute('href') === '#' + id) {
            item.style.color = '#fff';
          }
        });
      }
    });
  }, {
    threshold: 0.3,
    rootMargin: '-64px 0px -40% 0px'
  });

  sections.forEach(section => observer.observe(section));
}

/* ----------------------------------------
   TYPED EFFECT - Typing animation for role text
   ---------------------------------------- */
function initTypedEffect() {
  const typedEl = document.querySelector('.typed-text');
  if (!typedEl) return;

  const roles = [
    'Desenvolvedor Python',
    'Desenvolvedor C#',
    'Backend Developer',
    'Problem Solver'
  ];

  let roleIndex = 0;
  let charIndex = 0;
  let isDeleting = false;
  let typeSpeed = 80;

  function type() {
    const currentRole = roles[roleIndex];

    if (isDeleting) {
      typedEl.textContent = currentRole.substring(0, charIndex - 1);
      charIndex--;
      typeSpeed = 40;
    } else {
      typedEl.textContent = currentRole.substring(0, charIndex + 1);
      charIndex++;
      typeSpeed = 80;
    }

    if (!isDeleting && charIndex === currentRole.length) {
      // Pause at end of word
      typeSpeed = 2000;
      isDeleting = true;
    } else if (isDeleting && charIndex === 0) {
      isDeleting = false;
      roleIndex = (roleIndex + 1) % roles.length;
      typeSpeed = 400;
    }

    setTimeout(type, typeSpeed);
  }

  // Start after a small delay
  setTimeout(type, 1000);
}

/* ----------------------------------------
   FORM HANDLING - Simple mailto fallback
   ---------------------------------------- */
function handleContactForm(e) {
  e.preventDefault();
  const form = e.target;
  const name = form.querySelector('#name').value;
  const email = form.querySelector('#email').value;
  const message = form.querySelector('#message').value;

  // Mailto fallback for static sites
  const subject = encodeURIComponent(`Contato via Portfólio - ${name}`);
  const body = encodeURIComponent(`Nome: ${name}\nEmail: ${email}\n\nMensagem:\n${message}`);
  window.location.href = `mailto:es.guilhermemoreli@proton.me?subject=${subject}&body=${body}`;
}
