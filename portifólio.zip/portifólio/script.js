/* ============================================
   PORTFÓLIO - Guilherme Moreli
   JavaScript Principal
   ============================================ */
document.addEventListener('DOMContentLoaded', () => {
  // ---------- PRELOADER ----------
  const preloader = document.getElementById('preloader');
  window.addEventListener('load', () => {
    setTimeout(() => {
      preloader.classList.add('hidden');
    }, 500);
  });
  // Fallback: esconde o preloader após 3 segundos caso o load demore
  setTimeout(() => {
    preloader.classList.add('hidden');
  }, 3000);
  // ---------- NAVBAR SCROLL ----------
  const navbar = document.querySelector('.navbar');
  const backToTopBtn = document.getElementById('backToTop');
  const navLinks = document.querySelectorAll('.nav-link');
  const sections = document.querySelectorAll('section[id]');
  function handleScroll() {
    const scrollY = window.scrollY;
    // Navbar com fundo ao rolar
    if (scrollY > 50) {
      navbar.classList.add('scrolled');
    } else {
      navbar.classList.remove('scrolled');
    }
    // Botão voltar ao topo
    if (scrollY > 400) {
      backToTopBtn.classList.add('visible');
    } else {
      backToTopBtn.classList.remove('visible');
    }
    // Atualizar link ativo na navbar
    updateActiveNav();
  }
  window.addEventListener('scroll', handleScroll);
  // ---------- LINK ATIVO NA NAVBAR ----------
  function updateActiveNav() {
    const scrollY = window.scrollY + 150;
    sections.forEach(section => {
      const sectionTop = section.offsetTop;
      const sectionHeight = section.offsetHeight;
      const sectionId = section.getAttribute('id');
      if (scrollY >= sectionTop && scrollY < sectionTop + sectionHeight) {
        navLinks.forEach(link => {
          link.classList.remove('active');
          if (link.getAttribute('href') === `#${sectionId}`) {
            link.classList.add('active');
          }
        });
      }
    });
  }
  // ---------- FECHAR MENU MOBILE AO CLICAR ----------
  const navbarCollapse = document.querySelector('.navbar-collapse');
  navLinks.forEach(link => {
    link.addEventListener('click', () => {
      if (navbarCollapse.classList.contains('show')) {
        const bsCollapse = bootstrap.Collapse.getInstance(navbarCollapse);
        if (bsCollapse) bsCollapse.hide();
      }
    });
  });
  // ---------- BOTÃO VOLTAR AO TOPO ----------
  backToTopBtn.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });
  // ---------- ANIMAÇÕES DE ENTRADA (Intersection Observer) ----------
  const revealElements = document.querySelectorAll('.reveal');
  const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('active');
        // Não para de observar para permitir re-animação se necessário
      }
    });
  }, {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
  });
  revealElements.forEach(el => revealObserver.observe(el));
  // ---------- BARRAS DE HABILIDADE ----------
  const skillBars = document.querySelectorAll('.skill-bar-fill');
  const skillObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const targetWidth = entry.target.getAttribute('data-width');
        entry.target.style.width = targetWidth;
        skillObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.5 });
  skillBars.forEach(bar => skillObserver.observe(bar));
  // ---------- EFEITO DIGITAÇÃO (TYPING) ----------
  const typingElement = document.getElementById('typing-text');
  if (typingElement) {
    const words = ['Python', 'C#', '.NET', 'Django', 'Automação', 'APIs REST'];
    let wordIndex = 0;
    let charIndex = 0;
    let isDeleting = false;
    let typingSpeed = 100;
    function typeEffect() {
      const currentWord = words[wordIndex];
      if (isDeleting) {
        // Apagando
        typingElement.textContent = currentWord.substring(0, charIndex - 1);
        charIndex--;
        typingSpeed = 50;
      } else {
        // Digitando
        typingElement.textContent = currentWord.substring(0, charIndex + 1);
        charIndex++;
        typingSpeed = 100;
      }
      // Palavra completa
      if (!isDeleting && charIndex === currentWord.length) {
        typingSpeed = 2000; // Pausa no final
        isDeleting = true;
      }
      // Palavra apagada
      if (isDeleting && charIndex === 0) {
        isDeleting = false;
        wordIndex = (wordIndex + 1) % words.length;
        typingSpeed = 400; // Pausa antes da próxima
      }
      setTimeout(typeEffect, typingSpeed);
    }
    // Inicia após um pequeno delay
    setTimeout(typeEffect, 1500);
  }
  // ---------- CONTADOR ANIMADO ----------
  const counters = document.querySelectorAll('.counter');
  const counterObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const target = parseInt(entry.target.getAttribute('data-target'));
        const suffix = entry.target.getAttribute('data-suffix') || '';
        animateCounter(entry.target, target, suffix);
        counterObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.5 });
  counters.forEach(counter => counterObserver.observe(counter));
  function animateCounter(element, target, suffix) {
    let current = 0;
    const increment = target / 50;
    const timer = setInterval(() => {
      current += increment;
      if (current >= target) {
        current = target;
        clearInterval(timer);
      }
      element.textContent = Math.floor(current) + suffix;
    }, 30);
  }
  // ---------- FORMULÁRIO DE CONTATO ----------
  const contactForm = document.getElementById('contactForm');
  if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const submitBtn = contactForm.querySelector('button[type="submit"]');
      const originalText = submitBtn.innerHTML;
      // Simula envio
      submitBtn.innerHTML = '<i class="bi bi-hourglass-split me-2"></i>Enviando...';
      submitBtn.disabled = true;
      setTimeout(() => {
        submitBtn.innerHTML = '<i class="bi bi-check-circle me-2"></i>Enviado!';
        submitBtn.classList.remove('btn-primary-custom');
        submitBtn.style.background = '#10b981';
        // Limpa o formulário
        contactForm.reset();
        // Restaura o botão
        setTimeout(() => {
          submitBtn.innerHTML = originalText;
          submitBtn.disabled = false;
          submitBtn.classList.add('btn-primary-custom');
          submitBtn.style.background = '';
        }, 3000);
      }, 1500);
    });
  }
  // ---------- PARTÍCULAS FLUTUANTES NO HERO ----------
  function createParticles() {
    const hero = document.getElementById('hero');
    if (!hero) return;
    for (let i = 0; i < 20; i++) {
      const particle = document.createElement('div');
      particle.style.cssText = `
        position: absolute;
        width: ${Math.random() * 4 + 1}px;
        height: ${Math.random() * 4 + 1}px;
        background: rgba(0, 212, 255, ${Math.random() * 0.3 + 0.1});
        border-radius: 50%;
        top: ${Math.random() * 100}%;
        left: ${Math.random() * 100}%;
        pointer-events: none;
        animation: particleFloat ${Math.random() * 10 + 5}s ease-in-out infinite;
        animation-delay: ${Math.random() * 5}s;
        z-index: 1;
      `;
      hero.appendChild(particle);
    }
    // Adiciona a animação via CSS dinâmico
    if (!document.getElementById('particle-styles')) {
      const style = document.createElement('style');
      style.id = 'particle-styles';
      style.textContent = `
        @keyframes particleFloat {
          0%, 100% {
            transform: translateY(0) translateX(0);
            opacity: 0.3;
          }
          25% {
            transform: translateY(-30px) translateX(15px);
            opacity: 0.8;
          }
          50% {
            transform: translateY(-15px) translateX(-10px);
            opacity: 0.5;
          }
          75% {
            transform: translateY(-40px) translateX(20px);
            opacity: 0.7;
          }
        }
      `;
      document.head.appendChild(style);
    }
  }
  createParticles();
  // ---------- SMOOTH REVEAL PARA O HERO ----------
  const heroContent = document.querySelector('.hero-content');
  if (heroContent) {
    heroContent.style.opacity = '0';
    heroContent.style.transform = 'translateY(30px)';
    setTimeout(() => {
      heroContent.style.transition = 'all 1s cubic-bezier(0.4, 0, 0.2, 1)';
      heroContent.style.opacity = '1';
      heroContent.style.transform = 'translateY(0)';
    }, 600);
  }
  const heroImage = document.querySelector('.hero-image-wrapper');
  if (heroImage) {
    heroImage.style.opacity = '0';
    heroImage.style.transform = 'translateY(30px)';
    setTimeout(() => {
      heroImage.style.transition = 'all 1s cubic-bezier(0.4, 0, 0.2, 1)';
      heroImage.style.opacity = '1';
      heroImage.style.transform = 'translateY(0)';
    }, 900);
  }
});
