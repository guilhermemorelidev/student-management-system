/**
 * ============================================
 * PORTFÓLIO — GUILHERME MORELI
 * Desenvolvedor Python & C#
 *
 * Tema: Aesthetic escuro com roxo + buraco negro animado
 * Stack: React + Vite + Tailwind CSS
 * ============================================
 */
import { useEffect, useRef, useState } from "react";
/* ============================================
   COMPONENTE: Buraco Negro Animado (CSS puro)
   ============================================ */
function BlackHole({ className = "" }: { className?: string }) {
  return (
    <div className={`blackhole-container ${className}`} aria-hidden="true">
      {/* Brilho de fundo */}
      <div className="blackhole-glow" />
      {/* Lente gravitacional */}
      <div className="gravitational-lens" />
      {/* Discos de acreção girando */}
      <div className="accretion-disk accretion-disk-1" />
      <div className="accretion-disk accretion-disk-2" />
      <div className="accretion-disk accretion-disk-3" />
      {/* Núcleo escuro */}
      <div className="blackhole-core" />
      {/* Partículas flutuando */}
      <div className="particle particle-1" />
      <div className="particle particle-2" />
      <div className="particle particle-3" />
      <div className="particle particle-4" />
      <div className="particle particle-5" />
      <div className="particle particle-6" />
    </div>
  );
}
/* ============================================
   ÍCONES SVG INLINE
   ============================================ */
function IconGitHub({ size = 20 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor">
      <path d="M12 0C5.374 0 0 5.373 0 12c0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23A11.509 11.509 0 0112 5.803c1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576C20.566 21.797 24 17.3 24 12c0-6.627-5.373-12-12-12z" />
    </svg>
  );
}
function IconLinkedIn({ size = 20 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor">
      <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
    </svg>
  );
}
function IconMail({ size = 20 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect width="20" height="16" x="2" y="4" rx="2" />
      <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7" />
    </svg>
  );
}
function IconExternal({ size = 16 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
      <polyline points="15 3 21 3 21 9" />
      <line x1="10" y1="14" x2="21" y2="3" />
    </svg>
  );
}
function IconMenu({ size = 24 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <line x1="3" y1="6" x2="21" y2="6" />
      <line x1="3" y1="12" x2="21" y2="12" />
      <line x1="3" y1="18" x2="21" y2="18" />
    </svg>
  );
}
function IconClose({ size = 24 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <line x1="18" y1="6" x2="6" y2="18" />
      <line x1="6" y1="6" x2="18" y2="18" />
    </svg>
  );
}
function IconChevronDown({ size = 20 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="6 9 12 15 18 9" />
    </svg>
  );
}
/* ============================================
   DADOS DO PORTFÓLIO
   ============================================ */
/** Habilidades organizadas por categoria */
const skillsData = {
  "LINGUAGENS": ["Python", "C#", "JavaScript", "TypeScript", "SQL", "HTML", "CSS"],
  "FRAMEWORKS & LIBS": ["Django", "Flask", "FastAPI", ".NET", "ASP.NET", "React", "Tailwind CSS"],
  "FERRAMENTAS": ["Git", "GitHub", "Docker", "VS Code", "Linux", "PostgreSQL", "MongoDB"],
};
/** Projetos */
const projectsData = [
  {
    title: "API REST com FastAPI",
    description: "API RESTful completa com autenticação JWT, CRUD de usuários e documentação automática com Swagger.",
    tags: ["Python", "FastAPI", "PostgreSQL", "Docker"],
    github: "https://github.com/guilhermemorelidev",
    live: "",
  },
  {
    title: "Sistema de Gestão em C#",
    description: "Aplicação desktop para gestão de estoque e vendas com interface moderna e relatórios em PDF.",
    tags: ["C#", ".NET", "SQL Server", "WPF"],
    github: "https://github.com/guilhermemorelidev",
    live: "",
  },
  {
    title: "Dashboard Analytics",
    description: "Painel interativo com gráficos e métricas em tempo real, integrado com APIs externas.",
    tags: ["Python", "Django", "Chart.js", "REST API"],
    github: "https://github.com/guilhermemorelidev",
    live: "",
  },
  {
    title: "Bot de Automação",
    description: "Bot para automação de tarefas repetitivas com scraping de dados e envio de relatórios por e-mail.",
    tags: ["Python", "Selenium", "BeautifulSoup", "SMTP"],
    github: "https://github.com/guilhermemorelidev",
    live: "",
  },
];
/** Formação e cursos */
const educationData = [
  {
    title: "Ciência da Computação",
    institution: "Universidade — Em andamento",
    year: "2024 — Presente",
    description: "Graduação em Ciência da Computação com foco em desenvolvimento de software e algoritmos.",
  },
  {
    title: "Python Completo",
    institution: "Udemy / Curso Online",
    year: "2023",
    description: "Curso completo de Python do básico ao avançado, incluindo POO, Django e automação.",
  },
  {
    title: "C# e .NET",
    institution: "Plataforma de Ensino Online",
    year: "2023",
    description: "Desenvolvimento de aplicações com C#, .NET Core, ASP.NET e Entity Framework.",
  },
  {
    title: "Git e GitHub",
    institution: "Curso Online",
    year: "2022",
    description: "Controle de versão, branches, pull requests e boas práticas de colaboração.",
  },
];
/** Links de navegação */
const navLinks = [
  { label: "Home", href: "#home" },
  { label: "Sobre", href: "#sobre" },
  { label: "Habilidades", href: "#habilidades" },
  { label: "Projetos", href: "#projetos" },
  { label: "Formação", href: "#formacao" },
  { label: "Contato", href: "#contato" },
];
/* ============================================
   HOOK: Intersection Observer para animações
   ============================================ */
function useInView() {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          el.classList.add("visible");
        }
      },
      { threshold: 0.1 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);
  return ref;
}
/** Componente wrapper para seções que animam ao entrar na tela */
function AnimatedSection({
  children,
  className = "",
  id,
}: {
  children: React.ReactNode;
  className?: string;
  id?: string;
}) {
  const ref = useInView();
  return (
    <div ref={ref} id={id} className={`observe-section ${className}`}>
      {children}
    </div>
  );
}
/* ============================================
   COMPONENTE PRINCIPAL: App
   ============================================ */
export default function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  // Detecta scroll para estilizar o header
  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);
  // Fecha menu mobile ao clicar num link
  const handleNavClick = () => setMenuOpen(false);
  return (
    <div className="relative min-h-screen bg-[#0a0a0a] bg-grid">
      {/* ========================================
          SIDEBAR SOCIAL (Desktop) - lado esquerdo
          ======================================== */}
      <aside className="social-sidebar fixed left-6 top-1/2 -translate-y-1/2 z-50 hidden lg:flex flex-col gap-5 items-center">
        <a
          href="https://www.linkedin.com/in/guilhermemorelidev"
          target="_blank"
          rel="noopener noreferrer"
          className="text-[#666] hover:text-purple-glow"
          aria-label="LinkedIn"
        >
          <IconLinkedIn size={20} />
        </a>
        <a
          href="https://github.com/guilhermemorelidev"
          target="_blank"
          rel="noopener noreferrer"
          className="text-[#666] hover:text-purple-glow"
          aria-label="GitHub"
        >
          <IconGitHub size={20} />
        </a>
        <a
          href="mailto:es.guilhermemoreli@proton.me"
          className="text-[#666] hover:text-purple-glow"
          aria-label="Email"
        >
          <IconMail size={20} />
        </a>
        {/* Linha vertical decorativa */}
        <div className="w-px h-24 bg-gradient-to-b from-[#333] to-transparent mt-2" />
      </aside>
      {/* ========================================
          HEADER / NAVBAR
          ======================================== */}
      <header
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
          scrolled
            ? "bg-[#0a0a0a]/90 backdrop-blur-md border-b border-[#1a1a1a]"
            : "bg-transparent"
        }`}
      >
        <nav className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          {/* Logo / Nome */}
          <a href="#home" className="text-lg font-semibold tracking-tight">
            <span className="text-white">GM</span>
            <span className="text-purple-400">.</span>
          </a>
          {/* Links desktop */}
          <ul className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <li key={link.href}>
                <a
                  href={link.href}
                  className="nav-link text-sm text-[#888] hover:text-white uppercase tracking-widest font-medium"
                >
                  {link.label}
                </a>
              </li>
            ))}
          </ul>
          {/* Botão menu mobile */}
          <button
            onClick={() => setMenuOpen(!menuOpen)}
            className="md:hidden text-white p-1"
            aria-label="Menu"
          >
            {menuOpen ? <IconClose /> : <IconMenu />}
          </button>
        </nav>
        {/* Menu mobile */}
        {menuOpen && (
          <div className="md:hidden bg-[#0a0a0a]/95 backdrop-blur-lg border-t border-[#1a1a1a]">
            <ul className="flex flex-col items-center gap-6 py-8">
              {navLinks.map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    onClick={handleNavClick}
                    className="text-sm text-[#888] hover:text-white uppercase tracking-widest font-medium"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
              {/* Social mobile */}
              <li className="flex gap-6 pt-4 border-t border-[#1a1a1a] mt-2">
                <a href="https://www.linkedin.com/in/guilhermemorelidev" target="_blank" rel="noopener noreferrer" className="text-[#666] hover:text-purple-400">
                  <IconLinkedIn />
                </a>
                <a href="https://github.com/guilhermemorelidev" target="_blank" rel="noopener noreferrer" className="text-[#666] hover:text-purple-400">
                  <IconGitHub />
                </a>
                <a href="mailto:es.guilhermemoreli@proton.me" className="text-[#666] hover:text-purple-400">
                  <IconMail />
                </a>
              </li>
            </ul>
          </div>
        )}
      </header>
      {/* ========================================
          HERO SECTION
          ======================================== */}
      <section
        id="home"
        className="relative min-h-screen flex items-center justify-center overflow-hidden px-6"
      >
        {/* Gradiente de fundo decorativo */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-1/4 right-1/4 w-[500px] h-[500px] bg-purple-900/10 rounded-full blur-[120px]" />
          <div className="absolute bottom-1/4 left-1/4 w-[400px] h-[400px] bg-purple-800/5 rounded-full blur-[100px]" />
        </div>
        <div className="max-w-6xl mx-auto w-full grid lg:grid-cols-2 gap-12 items-center relative z-10">
          {/* Coluna esquerda: texto */}
          <div className="order-2 lg:order-1 text-center lg:text-left">
            <p className="fade-in-up text-sm uppercase tracking-[0.3em] text-purple-400 font-medium mb-4">
              Desenvolvedor Python &amp; C#
            </p>
            <h1 className="fade-in-up delay-100 text-4xl sm:text-5xl lg:text-6xl font-bold leading-tight tracking-tight">
              Guilherme
              <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-purple-300 to-purple-500">
                Moreli
              </span>
            </h1>
            <p className="fade-in-up delay-200 mt-6 text-[#888] text-base sm:text-lg max-w-md mx-auto lg:mx-0 leading-relaxed">
              Construindo soluções elegantes com código limpo.
              <br />
              Focado em back-end, automação e desenvolvimento de software.
            </p>
            {/* Botões CTA */}
            <div className="fade-in-up delay-300 mt-8 flex flex-wrap gap-4 justify-center lg:justify-start">
              <a
                href="https://github.com/guilhermemorelidev"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-6 py-3 bg-purple-600 hover:bg-purple-500 text-white text-sm font-medium rounded-lg transition-colors"
              >
                <IconGitHub size={18} />
                GitHub
              </a>
              <a
                href="https://www.linkedin.com/in/guilhermemorelidev"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-6 py-3 border border-[#333] hover:border-purple-500/50 text-white text-sm font-medium rounded-lg transition-colors"
              >
                <IconLinkedIn size={18} />
                LinkedIn
              </a>
            </div>
          </div>
          {/* Coluna direita: Buraco negro + foto */}
          <div className="order-1 lg:order-2 flex justify-center relative">
            <BlackHole />
            {/* Foto dentro do buraco negro */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-20">
              <div className="w-24 h-24 md:w-32 md:h-32 rounded-full overflow-hidden border-2 border-purple-500/30 shadow-[0_0_40px_rgba(139,92,246,0.2)]">
                <img
                  src="/img.jpeg"
                  alt="Guilherme Moreli"
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    // Fallback se a imagem não existir
                    (e.target as HTMLImageElement).style.display = 'none';
                  }}
                />
              </div>
            </div>
          </div>
        </div>
        {/* Scroll indicator */}
        <a
          href="#sobre"
          className="absolute bottom-8 left-1/2 -translate-x-1/2 text-[#555] hover:text-purple-400 transition-colors animate-bounce"
          aria-label="Rolar para baixo"
        >
          <IconChevronDown size={28} />
        </a>
      </section>
      {/* ========================================
          SOBRE MIM
          ======================================== */}
      <section id="sobre" className="py-24 px-6">
        <AnimatedSection className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Imagem grande */}
            <div className="relative group">
              <div className="relative overflow-hidden rounded-2xl border border-[#222] bg-[#111]">
                <img
                  src="/img.jpeg"
                  alt="Guilherme Moreli"
                  className="w-full h-[400px] lg:h-[500px] object-cover grayscale hover:grayscale-0 transition-all duration-700"
                  onError={(e) => {
                    // Fallback: mostra placeholder se img não existir
                    const target = e.target as HTMLImageElement;
                    target.src = 'data:image/svg+xml,' + encodeURIComponent(
                      '<svg xmlns="http://www.w3.org/2000/svg" width="600" height="500" fill="%23111"><rect width="600" height="500"/><text x="300" y="260" text-anchor="middle" fill="%23333" font-size="24" font-family="sans-serif">Sua foto aqui</text></svg>'
                    );
                  }}
                />
                {/* Overlay gradiente */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a]/60 to-transparent" />
              </div>
              {/* Decoração */}
              <div className="absolute -top-4 -right-4 w-24 h-24 border border-purple-500/20 rounded-2xl -z-10" />
              <div className="absolute -bottom-4 -left-4 w-24 h-24 border border-purple-500/10 rounded-2xl -z-10" />
            </div>
            {/* Texto sobre mim */}
            <div>
              <p className="text-sm uppercase tracking-[0.3em] text-purple-400 font-medium mb-3">
                Sobre mim
              </p>
              <h2 className="text-3xl sm:text-4xl font-bold mb-6 tracking-tight">
                Quem sou eu
              </h2>
              <div className="gradient-line mb-8" />
              <div className="space-y-4 text-[#999] leading-relaxed">
                <p>
                  Sou um desenvolvedor apaixonado por tecnologia, com foco principal em
                  <span className="text-white font-medium"> Python </span> e
                  <span className="text-white font-medium"> C#</span>.
                  Gosto de criar soluções eficientes e bem estruturadas, desde APIs robustas
                  até aplicações desktop completas.
                </p>
                <p>
                  Atualmente estou em constante evolução, explorando novas tecnologias
                  e aprimorando minhas habilidades tanto no back-end quanto no front-end.
                  Acredito que o código limpo e a boa arquitetura são fundamentais para
                  qualquer projeto de sucesso.
                </p>
                <p>
                  Quando não estou programando, estou estudando sobre design, astronomia
                  ou jogando algo. Sou fascinado por buracos negros e pelo universo — e isso
                  reflete até no design deste portfólio.
                </p>
              </div>
              {/* Info cards */}
              <div className="grid grid-cols-2 gap-4 mt-8">
                <div className="p-4 rounded-xl bg-[#111] border border-[#1a1a1a]">
                  <p className="text-2xl font-bold text-purple-400">2+</p>
                  <p className="text-xs text-[#666] mt-1 uppercase tracking-wider">Anos de estudo</p>
                </div>
                <div className="p-4 rounded-xl bg-[#111] border border-[#1a1a1a]">
                  <p className="text-2xl font-bold text-purple-400">10+</p>
                  <p className="text-xs text-[#666] mt-1 uppercase tracking-wider">Projetos</p>
                </div>
              </div>
            </div>
          </div>
        </AnimatedSection>
      </section>
      {/* ========================================
          HABILIDADES
          ======================================== */}
      <section id="habilidades" className="py-24 px-6">
        <AnimatedSection className="max-w-6xl mx-auto">
          <p className="text-sm uppercase tracking-[0.3em] text-purple-400 font-medium mb-3">
            Habilidades
          </p>
          <h2 className="text-3xl sm:text-4xl font-bold mb-4 tracking-tight">
            Skills
          </h2>
          <div className="gradient-line mb-16" />
          <div className="grid md:grid-cols-3 gap-12">
            {Object.entries(skillsData).map(([category, skills]) => (
              <div key={category}>
                <h3 className="text-sm font-semibold uppercase tracking-[0.2em] text-[#ccc] mb-6">
                  {category}
                </h3>
                <div className="flex flex-wrap gap-3">
                  {skills.map((skill) => (
                    <span
                      key={skill}
                      className="skill-tag px-4 py-2 text-sm text-[#999] border border-[#222] rounded-full cursor-default"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </AnimatedSection>
      </section>
      {/* ========================================
          PROJETOS
          ======================================== */}
      <section id="projetos" className="py-24 px-6">
        <AnimatedSection className="max-w-6xl mx-auto">
          <p className="text-sm uppercase tracking-[0.3em] text-purple-400 font-medium mb-3">
            Projetos
          </p>
          <h2 className="text-3xl sm:text-4xl font-bold mb-4 tracking-tight">
            Trabalhos recentes
          </h2>
          <div className="gradient-line mb-16" />
          <div className="grid md:grid-cols-2 gap-6">
            {projectsData.map((project, index) => (
              <div
                key={index}
                className="card-hover group p-6 rounded-2xl bg-[#111] border border-[#1a1a1a] relative overflow-hidden"
              >
                {/* Glow decorativo no hover */}
                <div className="absolute top-0 right-0 w-32 h-32 bg-purple-600/5 rounded-full blur-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                {/* Número do projeto */}
                <span className="text-[#1a1a1a] text-6xl font-black absolute top-4 right-6 group-hover:text-[#222] transition-colors">
                  {String(index + 1).padStart(2, "0")}
                </span>
                <div className="relative z-10">
                  <h3 className="text-xl font-semibold mb-3 text-white group-hover:text-purple-300 transition-colors">
                    {project.title}
                  </h3>
                  <p className="text-[#777] text-sm leading-relaxed mb-5">
                    {project.description}
                  </p>
                  {/* Tags */}
                  <div className="flex flex-wrap gap-2 mb-5">
                    {project.tags.map((tag) => (
                      <span
                        key={tag}
                        className="text-xs px-3 py-1 rounded-full bg-purple-500/10 text-purple-300 border border-purple-500/20"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                  {/* Links */}
                  <div className="flex gap-4">
                    {project.github && (
                      <a
                        href={project.github}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1.5 text-sm text-[#888] hover:text-purple-400 transition-colors"
                      >
                        <IconGitHub size={16} />
                        Código
                      </a>
                    )}
                    {project.live && (
                      <a
                        href={project.live}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1.5 text-sm text-[#888] hover:text-purple-400 transition-colors"
                      >
                        <IconExternal size={16} />
                        Demo
                      </a>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </AnimatedSection>
      </section>
      {/* ========================================
          FORMAÇÃO / CURSOS
          ======================================== */}
      <section id="formacao" className="py-24 px-6">
        <AnimatedSection className="max-w-6xl mx-auto">
          <p className="text-sm uppercase tracking-[0.3em] text-purple-400 font-medium mb-3">
            Formação
          </p>
          <h2 className="text-3xl sm:text-4xl font-bold mb-4 tracking-tight">
            Educação &amp; Cursos
          </h2>
          <div className="gradient-line mb-16" />
          {/* Timeline */}
          <div className="relative">
            {/* Linha vertical */}
            <div className="absolute left-0 md:left-8 top-0 bottom-0 w-px bg-gradient-to-b from-purple-500/30 via-[#222] to-transparent" />
            <div className="space-y-10">
              {educationData.map((edu, index) => (
                <div
                  key={index}
                  className="relative pl-8 md:pl-20 group"
                >
                  {/* Dot na timeline */}
                  <div className="absolute left-0 md:left-8 top-2 -translate-x-1/2 w-3 h-3 rounded-full bg-[#222] border-2 border-purple-500/40 group-hover:bg-purple-500 group-hover:border-purple-400 transition-all duration-300" />
                  <div className="card-hover p-6 rounded-2xl bg-[#111] border border-[#1a1a1a]">
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-3">
                      <h3 className="text-lg font-semibold text-white group-hover:text-purple-300 transition-colors">
                        {edu.title}
                      </h3>
                      <span className="text-xs text-purple-400 bg-purple-500/10 px-3 py-1 rounded-full border border-purple-500/20 whitespace-nowrap">
                        {edu.year}
                      </span>
                    </div>
                    <p className="text-sm text-[#666] mb-2 font-medium">{edu.institution}</p>
                    <p className="text-sm text-[#777] leading-relaxed">{edu.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </AnimatedSection>
      </section>
      {/* ========================================
          CONTATO
          ======================================== */}
      <section id="contato" className="py-24 px-6">
        <AnimatedSection className="max-w-4xl mx-auto text-center">
          <p className="text-sm uppercase tracking-[0.3em] text-purple-400 font-medium mb-3">
            Contato
          </p>
          <h2 className="text-3xl sm:text-4xl font-bold mb-4 tracking-tight">
            Vamos conversar?
          </h2>
          <div className="gradient-line mb-8 max-w-xs mx-auto" />
          <p className="text-[#888] max-w-lg mx-auto mb-10 leading-relaxed">
            Estou sempre aberto a novas oportunidades, projetos interessantes e
            conversas sobre tecnologia. Fique à vontade para entrar em contato!
          </p>
          {/* Email destaque */}
          <a
            href="mailto:es.guilhermemoreli@proton.me"
            className="inline-flex items-center gap-3 text-lg sm:text-xl font-medium text-white hover:text-purple-400 transition-colors mb-10 group"
          >
            <span className="p-3 rounded-xl bg-purple-500/10 border border-purple-500/20 group-hover:bg-purple-500/20 transition-colors">
              <IconMail size={22} />
            </span>
            es.guilhermemoreli@proton.me
          </a>
          {/* Botões sociais */}
          <div className="flex justify-center gap-4 mt-8">
            <a
              href="https://github.com/guilhermemorelidev"
              target="_blank"
              rel="noopener noreferrer"
              className="p-4 rounded-xl bg-[#111] border border-[#1a1a1a] text-[#888] hover:text-white hover:border-purple-500/30 hover:bg-[#161616] transition-all"
              aria-label="GitHub"
            >
              <IconGitHub size={24} />
            </a>
            <a
              href="https://www.linkedin.com/in/guilhermemorelidev"
              target="_blank"
              rel="noopener noreferrer"
              className="p-4 rounded-xl bg-[#111] border border-[#1a1a1a] text-[#888] hover:text-white hover:border-purple-500/30 hover:bg-[#161616] transition-all"
              aria-label="LinkedIn"
            >
              <IconLinkedIn size={24} />
            </a>
            <a
              href="mailto:es.guilhermemoreli@proton.me"
              className="p-4 rounded-xl bg-[#111] border border-[#1a1a1a] text-[#888] hover:text-white hover:border-purple-500/30 hover:bg-[#161616] transition-all"
              aria-label="Email"
            >
              <IconMail size={24} />
            </a>
          </div>
        </AnimatedSection>
      </section>
      {/* ========================================
          FOOTER
          ======================================== */}
      <footer className="border-t border-[#1a1a1a] py-8 px-6">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-sm text-[#555]">
            © {new Date().getFullYear()} Guilherme Moreli. Todos os direitos reservados.
          </p>
          <div className="flex items-center gap-6">
            <a
              href="https://github.com/guilhermemorelidev"
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#555] hover:text-purple-400 transition-colors text-sm"
            >
              GitHub
            </a>
            <a
              href="https://www.linkedin.com/in/guilhermemorelidev"
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#555] hover:text-purple-400 transition-colors text-sm"
            >
              LinkedIn
            </a>
            <a
              href="mailto:es.guilhermemoreli@proton.me"
              className="text-[#555] hover:text-purple-400 transition-colors text-sm"
            >
              Email
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}
